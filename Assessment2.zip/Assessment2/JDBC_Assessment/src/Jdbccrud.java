


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Jdbccrud {
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/myhiber";
    static final String USER = "root";
    static final String PASSWORD = "root";

    public static void main(String[] args) {
        try 
        {
        	Class.forName("com.mysql.jdbc.Driver");
        	
            Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            
            System.out.println("Connected to the database");

            createTable(connection);

            System.out.println();
           insertData(connection, "Priyansh", "Jagtap");

           
            readData(connection);

            System.out.println();
            updateData(connection, 1, "Patil");

           
            readData(connection);

           System.out.println();
            deleteData(connection, 2);

           
            readData(connection);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public static void createTable(Connection connection) {
        try
        {
        	Statement statement = connection.createStatement();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS employees ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "first_name VARCHAR(255),"
                    + "last_name VARCHAR(255))";
            
            statement.executeUpdate(createTableSQL);
            System.out.println("Table created successfully");
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    }

    public static void insertData(Connection connection, String firstName, String lastName)
    {
        try 
        {
        	Statement statement = connection.createStatement();
            String insertSQL = "INSERT INTO employees (first_name, last_name) VALUES ('" + firstName + "', '" + lastName + "')";
            statement.executeUpdate(insertSQL);
            System.out.println("Data inserted successfully");
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        
    }

    public static void readData(Connection connection) 
    {
    	   try 
           {
           	Statement statement = connection.createStatement();
            String selectSQL = "SELECT * FROM employees";
            ResultSet resultSet = statement.executeQuery(selectSQL);

            System.out.println("Employee Data:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                System.out.println("ID: " + id + ", First Name: " + firstName + ", Last Name: " + lastName);
            }
           }
    	   catch(Exception e)
           {
           	e.printStackTrace();
           }
           
    	   
       }
    

    public static void updateData(Connection connection, int id, String firstName){
    	
        try 
        {
        	Statement statement = connection.createStatement();
            String updateSQL = "UPDATE employees SET first_name = '" + firstName + "' WHERE id = " + id;
            statement.executeUpdate(updateSQL);
            System.out.println("Data updated successfully");
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        
    }

    public static void deleteData(Connection connection, int id) 
    {
        try
        {
        	Statement statement = connection.createStatement();
            String deleteSQL = "DELETE FROM employees WHERE id = " + id;
            statement.executeUpdate(deleteSQL);
            System.out.println("Data deleted successfully");
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        
    }
}
