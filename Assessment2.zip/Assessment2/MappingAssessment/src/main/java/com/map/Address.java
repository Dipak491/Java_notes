package com.map;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="Address123")

public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long a_id;

    private String addr;
    @OneToMany(mappedBy = "address", cascade = CascadeType.ALL)
    private List<Employee> employee = new ArrayList<> ();


	
    // Constructors, getters, setters
  



	public Long getA_id() {
		return a_id;
	}



	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}



	public void setA_id(Long a_id) {
		this.a_id = a_id;
	}



	public String getAddr() {
		return addr;
	}



	public void setAddr(String addr) {
		this.addr = addr;
	}



	public List<Employee> getEmployee() {
		return employee;
	}



	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

}
