package com.map;


import javax.persistence.*;

@Entity
@Table(name="Employee123")
public class Employee {


	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long e_id;
    public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Long getE_id() {
		return e_id;
	}

	public void setE_id(Long e_id) {
		this.e_id = e_id;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	private String ename;

    @ManyToOne
    @JoinColumn(name = "a_id")
    private Address address;
    
    @ManyToOne
    @JoinColumn(name = "d_id")
    private Department department;

    // Constructors, getters, setters
}
