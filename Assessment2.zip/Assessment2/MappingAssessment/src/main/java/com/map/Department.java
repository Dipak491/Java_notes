package com.map;


import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="Department123")

public class Department {
    

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long d_id;

    public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getD_id() {
		return d_id;
	}

	public void setD_id(Long d_id) {
		this.d_id = d_id;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	private String dname;

    @OneToMany(mappedBy = "department", cascade = CascadeType.ALL)
    private List<Employee> employee = new ArrayList<>();


    @Override
	public String toString() {
		return "Department [d_id=" + d_id + ", dname=" + dname + ", employee=" + employee + "]";
	}
    // Constructors, getters, setters
}
