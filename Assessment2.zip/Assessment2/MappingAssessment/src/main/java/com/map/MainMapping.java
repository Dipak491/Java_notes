package com.map;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainMapping 
{
    public static void main(String[] args)
    {
          
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("myPU");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Address address = new Address();
        address.setAddr("pune");

        Department department=new Department();
        department.setDname("Mechanical");

        Employee employee1 = new Employee();
        employee1.setEname("Arijit");
        employee1.setAddress(address);
        employee1.setDepartment(department);

        Employee employee2 = new Employee();
        employee2.setEname("Rushikesh");
        employee2.setAddress(address);
        employee2.setDepartment(department);

        address.getEmployee().add(employee1);
        address.getEmployee().add(employee2);

        department.getEmployee().add(employee1);
        department.getEmployee().add(employee2);

        em.persist(address);
        em.persist(department);
        em.persist(employee1);
        em.persist(employee2);

        //System.out.println(department.getEmployee());
        
        System.out.println("Sucess");
        em.getTransaction().commit();

        em.close();
        emf.close();

    }
}
